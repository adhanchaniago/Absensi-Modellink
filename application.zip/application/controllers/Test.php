<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Test extends CI_Controller
{
    public function __construct()
    {
      parent::__construct();
      //Do your magic here
      $this->load->library(array('form_validation', 'secure_sess'));
      $this->load->model('absensi_m');
    }
public function index(){
    echo json_encode($this->absensi_m->getLaporanPerKelas(2,1));
}
}