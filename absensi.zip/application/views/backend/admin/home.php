<section class="content">
  <div class="box box-primary">
    <div class="box-header with-border">
      <h1 class="box-title">Selamat Datang, <?= $profile->nama;?></h1>
    </div>
    <!-- /.box-header -->
    <div class="box-body">
      <img src="<?= base_url()?>assets/gambar/home.jpg" style="max-width:100%">
    </div>
    <!-- /.box-body -->
  </div>
</section>